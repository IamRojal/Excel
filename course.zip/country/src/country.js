import { API } from '@aws-amplify/api';
import config from '../src/aws-exports.js';
import { listCountries } from './graphql/queries.js';
import { createCountry } from './graphql/mutations.js';

// after your imports
API.configure(config);

// later down in your code
async function list() {
  
  try {
    let response=await API.graphql({
      query: listCountries,
      variables: {
        // Optional: If you want to add any filters or pagination variables, you can define them here.
        // Example: filter: { id: { eq: 'someId' } }, limit: 10, nextToken: null
      },
    })

    if (response.data && response.data.listCountries) {
      const designationsList = response.data.listCountries.items;
      console.log('Designations List:');
      designationsList.forEach((designation) => {
        console.log(designation);
      });
    } else {
      console.log('No data received or invalid response structure.');
    }
  } catch (error) {
    console.log('catch error '.error);
  }
}

// Call the function to insert data
list();

