/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateCountry = /* GraphQL */ `
  subscription OnCreateCountry(
    $country_name: String
    $country_code: String
    $short_code: String
  ) {
    onCreateCountry(
      country_name: $country_name
      country_code: $country_code
      short_code: $short_code
    ) {
      country_name
      country_code
      short_code
      __typename
    }
  }
`;
export const onUpdateCountry = /* GraphQL */ `
  subscription OnUpdateCountry(
    $country_name: String
    $country_code: String
    $short_code: String
  ) {
    onUpdateCountry(
      country_name: $country_name
      country_code: $country_code
      short_code: $short_code
    ) {
      country_name
      country_code
      short_code
      __typename
    }
  }
`;
export const onDeleteCountry = /* GraphQL */ `
  subscription OnDeleteCountry(
    $country_name: String
    $country_code: String
    $short_code: String
  ) {
    onDeleteCountry(
      country_name: $country_name
      country_code: $country_code
      short_code: $short_code
    ) {
      country_name
      country_code
      short_code
      __typename
    }
  }
`;
