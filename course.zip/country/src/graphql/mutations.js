/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createCountry = /* GraphQL */ `
  mutation CreateCountry($input: CreateCountryInput!) {
    createCountry(input: $input) {
      country_name
      country_code
      short_code
      __typename
    }
  }
`;
export const updateCountry = /* GraphQL */ `
  mutation UpdateCountry($input: UpdateCountryInput!) {
    updateCountry(input: $input) {
      country_name
      country_code
      short_code
      __typename
    }
  }
`;
export const deleteCountry = /* GraphQL */ `
  mutation DeleteCountry($input: DeleteCountryInput!) {
    deleteCountry(input: $input) {
      country_name
      country_code
      short_code
      __typename
    }
  }
`;
