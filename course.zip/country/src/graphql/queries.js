/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const getCountry = /* GraphQL */ `
  query GetCountry($country_name: String!) {
    getCountry(country_name: $country_name) {
      country_name
      country_code
      short_code
      __typename
    }
  }
`;
export const listCountries = /* GraphQL */ `
  query ListCountries(
    $filter: TableCountryFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listCountries(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        country_name
        country_code
        short_code
        __typename
      }
      nextToken
      __typename
    }
  }
`;
