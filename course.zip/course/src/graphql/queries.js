/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const getCourseDetails = /* GraphQL */ `
  query GetCourseDetails($course_id: String!) {
    getCourseDetails(course_id: $course_id) {
      course_id
      course_title
      benefits
      course_category
      course_description
      documents
      duration_count
      duration_type
      featured_image
      numberofclasses
      other_details
      related_courses
      summary
      syllabus
      trainers
      trainers_id
      __typename
    }
  }
`;
export const listCourseDetails = /* GraphQL */ `
  query ListCourseDetails(
    $filter: TableCourseDetailsFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listCourseDetails(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        course_id
        course_title
        benefits
        course_category
        course_description
        documents
        duration_count
        duration_type
        featured_image
        numberofclasses
        other_details
        related_courses
        summary
        syllabus
        trainers
        trainers_id
        __typename
      }
      nextToken
      __typename
    }
  }
`;
