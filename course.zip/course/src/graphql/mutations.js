/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createCourseDetails = /* GraphQL */ `
  mutation CreateCourseDetails($input: CreateCourseDetailsInput!) {
    createCourseDetails(input: $input) {
      course_id
      course_title
      benefits
      course_category
      course_description
      documents
      duration_count
      duration_type
      featured_image
      numberofclasses
      other_details
      related_courses
      summary
      syllabus
      trainers
      trainers_id
      __typename
    }
  }
`;
export const updateCourseDetails = /* GraphQL */ `
  mutation UpdateCourseDetails($input: UpdateCourseDetailsInput!) {
    updateCourseDetails(input: $input) {
      course_id
      course_title
      benefits
      course_category
      course_description
      documents
      duration_count
      duration_type
      featured_image
      numberofclasses
      other_details
      related_courses
      summary
      syllabus
      trainers
      trainers_id
      __typename
    }
  }
`;
export const deleteCourseDetails = /* GraphQL */ `
  mutation DeleteCourseDetails($input: DeleteCourseDetailsInput!) {
    deleteCourseDetails(input: $input) {
      course_id
      course_title
      benefits
      course_category
      course_description
      documents
      duration_count
      duration_type
      featured_image
      numberofclasses
      other_details
      related_courses
      summary
      syllabus
      trainers
      trainers_id
      __typename
    }
  }
`;
