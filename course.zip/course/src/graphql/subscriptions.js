/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateCourseDetails = /* GraphQL */ `
  subscription OnCreateCourseDetails(
    $course_id: String
    $course_title: String
    $benefits: String
    $course_category: String
    $course_description: String
  ) {
    onCreateCourseDetails(
      course_id: $course_id
      course_title: $course_title
      benefits: $benefits
      course_category: $course_category
      course_description: $course_description
    ) {
      course_id
      course_title
      benefits
      course_category
      course_description
      documents
      duration_count
      duration_type
      featured_image
      numberofclasses
      other_details
      related_courses
      summary
      syllabus
      trainers
      trainers_id
      __typename
    }
  }
`;
export const onUpdateCourseDetails = /* GraphQL */ `
  subscription OnUpdateCourseDetails(
    $course_id: String
    $course_title: String
    $benefits: String
    $course_category: String
    $course_description: String
  ) {
    onUpdateCourseDetails(
      course_id: $course_id
      course_title: $course_title
      benefits: $benefits
      course_category: $course_category
      course_description: $course_description
    ) {
      course_id
      course_title
      benefits
      course_category
      course_description
      documents
      duration_count
      duration_type
      featured_image
      numberofclasses
      other_details
      related_courses
      summary
      syllabus
      trainers
      trainers_id
      __typename
    }
  }
`;
export const onDeleteCourseDetails = /* GraphQL */ `
  subscription OnDeleteCourseDetails(
    $course_id: String
    $course_title: String
    $benefits: String
    $course_category: String
    $course_description: String
  ) {
    onDeleteCourseDetails(
      course_id: $course_id
      course_title: $course_title
      benefits: $benefits
      course_category: $course_category
      course_description: $course_description
    ) {
      course_id
      course_title
      benefits
      course_category
      course_description
      documents
      duration_count
      duration_type
      featured_image
      numberofclasses
      other_details
      related_courses
      summary
      syllabus
      trainers
      trainers_id
      __typename
    }
  }
`;
