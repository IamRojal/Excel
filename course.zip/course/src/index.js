// top of file
import { API } from '@aws-amplify/api'
import config from '../src/aws-exports.js'
import { listCourseDetails } from '../src/graphql/queries.js'
import { createCourseDetails,updateCourseDetails ,deleteCourseDetails} from '../src/graphql/mutations.js'

// after your imports
API.configure(config)

export const handler = async(event) => {
     try {
        if(event.type=='add'){
          return courseAdd(event);
        }
         if(event.type=='update'){
          return courseUpdate(event);
        }
         if(event.type=='delete'){
          return courseDelete(event);
        }
        return courseList()
    }
    catch (e) {
        return {status:'500',error:e,data:'error'};
    }
};

const courseAdd = async (event)=>{
    const variables = {
        input: {...event.data},
    };
    await API.graphql({query: createCourseDetails,variables});
    return {status:'200',data:'success'};
}


const courseUpdate = async (event)=>{
    const variables = {
        input: {...event.data},
    };
    await API.graphql({query: updateCourseDetails,variables});
    return {status:'200',data:'success'};
}


const courseDelete = async (event)=>{
    const variables = {
        input: {...event.data},
    };
    await API.graphql({query: deleteCourseDetails,variables});
    return {status:'200',data:'success'};
}


const courseList = async ()=>{
    const response = await API.graphql({query: listCourseDetails});
    return {status:'200',data:response?.data?.listCourseDetails?.items||[]};
}